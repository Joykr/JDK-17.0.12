package com.hand.xmc.infra.mapper;

import io.choerodon.mybatis.common.BaseMapper;
import com.hand.xmc.domain.entity.Example;

/**
 * Mapper
 */
public interface ExampleMapper extends BaseMapper<Example> {

}
