package com.hand.xmc.infra.constant;

/**
 * Utils
 */
public class Constants {

    private Constants() {}


}
