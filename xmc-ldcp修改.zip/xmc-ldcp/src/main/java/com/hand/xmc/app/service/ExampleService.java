package com.hand.xmc.app.service;

/**
 * ExampleService
 */
public interface ExampleService {

}
