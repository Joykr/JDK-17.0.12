package com.hand.xmc.app.service.impl;

import com.hand.xmc.app.service.ExampleService;
import org.springframework.stereotype.Service;

/**
 * ExampleServiceImpl
 */
@Service
public class ExampleServiceImpl implements ExampleService {

}
