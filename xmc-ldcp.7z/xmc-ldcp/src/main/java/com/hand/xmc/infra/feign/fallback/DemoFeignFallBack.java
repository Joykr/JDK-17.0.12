package com.hand.xmc.infra.feign.fallback;

import com.hand.xmc.infra.feign.DemoFeign;
import org.springframework.stereotype.Component;

/**
 * DemoFeignFallBack
 */
@Component
public class DemoFeignFallBack implements DemoFeign {

}
