package com.hand.xmc.domain.service.impl;

import com.hand.xmc.domain.service.SpecialService;
import org.springframework.stereotype.Component;

/**
 * 业务领域服务
 */
@Component
public class SpecialServiceImpl extends SpecialService {

}
