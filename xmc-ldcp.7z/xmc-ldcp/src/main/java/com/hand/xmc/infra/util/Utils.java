package com.hand.xmc.infra.util;

/**
 * Utils
 */
public class Utils {
    private Utils() {}
}
