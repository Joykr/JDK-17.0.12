package com.hand.xmc.domain.repository;

import com.hand.xmc.domain.entity.Example;
import org.hzero.mybatis.base.BaseRepository;

/**
 * Repository
 */
public interface ExampleRepository extends BaseRepository<Example> {

}
