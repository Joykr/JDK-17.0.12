package com.hand.xmc.domain.service;

/**
 * 业务领域服务
 */
public abstract class SpecialService {

}
